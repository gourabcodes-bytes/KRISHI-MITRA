# KRISHI-MITRA — Smart Agriculture & Allied Sector Monitoring System

**Seva First Innovation Challenge – Eastern Region**  
**Category: Agriculture & Allied Sector**

> KRISHI-MITRA is an independent student/research submission. It is not officially affiliated with, endorsed by, or sponsored by Seva First, the Government of West Bengal, or any government agency. Open satellite and weather datasets are used as factual data sources only.

---

## Overview

KRISHI-MITRA is a lightweight, farmer-friendly web application that turns open weather and satellite data, local soil information, and regional crop calendars into simple farm decisions. It is designed for smallholder farmers in Eastern India and works in English and Bengali, on desktop and basic smartphones, in light or dark mode.

The current release focuses on crop farms. Allied sectors such as livestock, dairy, fisheries, poultry, and dedicated field sensors are part of the future scope and are not presented as implemented features.

## What the app does today

- **My Farm:** weather, rainfall, soil moisture, and crop condition summary for the selected plot.
- **Weather & Alerts:** rainfall, temperature, humidity, and simple hazard alerts.
- **Crop Planner:** a 12-month crop rotation plan with a what-if scenario view.
- **Soil Test & Risk:** soil pH, salinity, and multi-hazard screening with plain-language advice.
- **Farm Recovery:** staged recovery checklist, field notes, and evidence tracking.
- **Crop Health Map:** interactive map with regional greenness, moisture, and rainfall context.
- **Reports:** printable advisory, CSV export, and server-generated PDF.
- **Data Sources:** farmer-friendly explanations of where the information comes from and its limits.

No fake sensor readings or unsupported AI claims are used. Sample data is clearly labelled and never presented as live measurements.

## Design principles

- Minimal green-and-white palette with accessible light and dark modes.
- Few menus, short labels, and important information visible immediately.
- Plain farmer-friendly language in English and Bengali.
- Honest data states: live, sample, cached, or unavailable are clearly distinguished.
- No heavy gradients, glows, or decorative complexity.

### Colour tokens

| Token | Value |
| --- | --- |
| Primary | `#2E7D32` |
| Secondary | `#A5D6A7` |
| Background | `#F8FAF7` |
| Surface | `#FFFFFF` |
| Text | `#26332B` |
| Secondary text | `#78847B` |
| Accent | `#DCC9A3` |

## Technical architecture

```text
React 18 + Vite frontend
  ├── React Router for routes
  ├── Leaflet for interactive maps
  ├── Recharts for simple charts
  ├── FarmContext for farm/session state
  └── ThemeContext for light/dark/system preference

Express.js backend (AgroVision_backend-main/)
  ├── /api and /api/v1 REST routes
  ├── Open weather and satellite data integrations
  ├── Optional MongoDB persistence with in-memory fallback
  ├── Risk, crop rotation, and environmental normalisation services
  └── PDF/CSV report generators
```

The backend folder and API paths retain their original names for compatibility with existing deployments and integrations.

## Data and honesty

KRISHI-MITRA uses open weather and satellite datasets, regional agricultural calendars, and farmer-recorded plot details. Gridded satellite and weather estimates describe regional conditions at coarse resolution. They do **not** replace laboratory soil testing, field drainage checks, or verification by a local agricultural officer.

Refer to the in-app **Data Sources** page for plain-language explanations and technical limitations.

## Future scope

- Livestock, dairy, fisheries, and poultry modules.
- Dedicated field sensor integration.
- More Indian languages and voice-first access.
- Expanded regional coverage beyond West Bengal.
- Integration with government soil health and weather portals.

## Getting started

```bash
npm install
npm run dev
```

Build the production frontend:

```bash
npm run build
```

Run the backend test suite:

```bash
node --test AgroVision_backend-main/tests/*.test.js
```

Start the backend only:

```bash
cd AgroVision_backend-main
npm install
npm start
```

## Project structure

```text
src/                         React frontend
  ├── config/brand.js        Canonical KRISHI-MITRA identity
  ├── context/               Farm and theme state
  ├── pages/                 Public and dashboard pages
  ├── components/            Shared UI and maps
  ├── services/              Frontend API clients and fallbacks
  └── styles/                Green/white design tokens and components

AgroVision_backend-main/    Express backend, integrations, and reports
public/assets/              KRISHI-MITRA logo and static assets
```

## Competition notice

Built for the **Seva First Innovation Challenge – Eastern Region** under the **Agriculture & Allied Sector** category. Official challenge site: <https://sficeast.wb.gov.in/en>.

This is an independent submission and does not represent an official partnership, endorsement, or affiliation with Seva First, the Government of West Bengal, or any government agency.
