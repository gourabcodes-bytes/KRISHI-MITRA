import React, { useState, useEffect } from 'react';
import { useFarm } from '../../context/FarmContext';
import { cropService } from '../../services/cropService';
import DataSourceCard from '../../components/common/DataSourceCard';
import {
  Repeat,
  Droplets,
  Leaf,
  ShieldCheck,
  Sliders,
  Calendar,
  CheckCircle2,
  ArrowRight,
  Sun
} from 'lucide-react';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function CropPlannerPage() {
  const { activeFarm, updateActiveFarmRotation, t } = useFarm();
  const [recommendations, setRecommendations] = useState([]);
  const [currentRotation, setCurrentRotation] = useState([]);
  const [appliedPlanId, setAppliedPlanId] = useState(null);

  const [delayDays, setDelayDays] = useState(0);
  const [tempOffset, setTempOffset] = useState(0.0);
  const [rainOffset, setRainOffset] = useState(0);
  const [simulationResult, setSimulationResult] = useState(null);
  const [showSimulation, setShowSimulation] = useState(false);

  useEffect(() => {
    if (!activeFarm) return;

    const initialRot = MONTHS.map((m, idx) => {
      if (Array.isArray(activeFarm.currentRotation) && activeFarm.currentRotation[idx]) {
        return { ...activeFarm.currentRotation[idx], month: m };
      }
      const cropFromMap = activeFarm.monthlyRotation?.[m] || 'Fallow';
      return {
        month: m,
        crop: cropFromMap,
        stage: cropFromMap === 'Fallow' ? 'Resting' : 'Active Stand'
      };
    });
    setCurrentRotation(initialRot);

    async function fetchRecs() {
      const res = await cropService.getRotationRecommendations(activeFarm.id, initialRot);
      setRecommendations(res.data || []);
    }
    fetchRecs();

    runSimulation(0, 0.0, 0);
  }, [activeFarm]);

  const runSimulation = async (delay, temp, rain) => {
    if (!activeFarm) return;
    const res = await cropService.simulateClimateScenario({
      farmId: activeFarm.id,
      sowingDelayDays: delay,
      tempOffsetCelsius: temp,
      rainfallOffsetPercent: rain
    });
    setSimulationResult(res);
  };

  const handleRotationChange = async (monthIndex, newCrop) => {
    const normalized = MONTHS.map((m, idx) => {
      const existing = currentRotation[idx];
      return existing ? { ...existing } : { month: m, crop: 'Fallow', stage: 'Resting' };
    });
    normalized[monthIndex] = {
      ...normalized[monthIndex],
      month: MONTHS[monthIndex],
      crop: newCrop,
      stage: newCrop === 'Fallow' ? 'Resting' : 'Scheduled'
    };
    setCurrentRotation(normalized);
    if (updateActiveFarmRotation) {
      updateActiveFarmRotation(normalized);
    }
    const res = await cropService.getRotationRecommendations(activeFarm.id, normalized);
    setRecommendations(res.data || []);
  };

  const handleApplyPlanToCalendar = (plan) => {
    const seqText = plan.sequence || '';
    const isCoastalPlan = seqText.includes('Khesari') || seqText.includes('Luna');
    const isMustardPlan = seqText.includes('Mustard');

    const newRot = MONTHS.map((m) => {
      if (['Jul', 'Aug', 'Sep', 'Oct'].includes(m)) {
        return { month: m, crop: 'Aman Paddy', stage: 'Kharif Stand' };
      }
      if (['Nov', 'Dec', 'Jan', 'Feb'].includes(m)) {
        const rabiCrop = isCoastalPlan ? 'Khesari' : isMustardPlan ? 'Mustard' : 'Potato';
        return { month: m, crop: rabiCrop, stage: 'Rabi Window' };
      }
      if (['Mar', 'Apr', 'May'].includes(m)) {
        return { month: m, crop: 'Moong', stage: 'Summer N-Fixation' };
      }
      return { month: m, crop: 'Fallow', stage: 'Pre-Monsoon Rest' };
    });

    setCurrentRotation(newRot);
    if (updateActiveFarmRotation) {
      updateActiveFarmRotation(newRot);
    }
    setAppliedPlanId(plan.id);
    setTimeout(() => setAppliedPlanId(null), 4000);
  };

  if (!activeFarm) {
    return (
      <div className="card" style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--color-text)' }}>
        {t('Loading crop rotation planner...', 'ফসল পরিকল্পক লোড করা হচ্ছে...')}
      </div>
    );
  }

  const cropColors = {
    Paddy: { bg: 'rgba(46, 125, 50, 0.12)', border: 'var(--color-primary)', color: 'var(--color-primary)' },
    Potato: { bg: 'rgba(176, 117, 37, 0.12)', border: '#B07525', color: '#B07525' },
    Mustard: { bg: 'rgba(220, 201, 163, 0.12)', border: '#DCC9A3', color: '#B07525' },
    Sesame: { bg: 'rgba(220, 201, 163, 0.12)', border: '#DCC9A3', color: '#B07525' },
    Moong: { bg: 'rgba(46, 125, 50, 0.12)', border: 'var(--color-primary)', color: 'var(--color-primary)' },
    Lentil: { bg: 'rgba(46, 125, 50, 0.12)', border: 'var(--color-primary)', color: 'var(--color-primary)' },
    Khesari: { bg: 'rgba(46, 125, 50, 0.12)', border: 'var(--color-primary)', color: 'var(--color-primary)' },
    Jute: { bg: 'rgba(46, 125, 50, 0.12)', border: 'var(--color-primary)', color: 'var(--color-primary)' },
    Fallow: { bg: 'transparent', border: 'var(--color-border)', color: 'var(--color-text-muted)' }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '1.35rem' }}>
        <h1 style={{ fontSize: '1.85rem', color: 'var(--color-text)', marginBottom: '0.25rem' }}>
          {t('Crop Planner & 12-Month Calendar', 'ফসল পরিকল্পনা ও ১২ মাসের ক্যালেন্ডার')}
        </h1>
        <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem', margin: 0 }}>
          {t('Plan your 12-month cropping calendar with weather and soil context for ', 'আবহাওয়া ও মাটির প্রেক্ষাপটে আপনার ১২ মাসের ফসল ক্যালেন্ডার পরিকল্পনা করুন — ')}
          <strong style={{ color: 'var(--color-primary)' }}>{activeFarm.name}</strong>.
        </p>
      </div>

      {/* 1. 12-Month Calendar */}
      <div className="card" style={{ marginBottom: '1.75rem' }}>
        <div className="card-header">
          <h3 className="card-title">
            <Calendar size={20} style={{ color: 'var(--color-primary)' }} />
            <span>{t('12-Month Cropping Calendar', '১২ মাসের ফসল ক্যালেন্ডার')}</span>
          </h3>
          <span style={{ fontSize: '0.76rem', fontFamily: 'var(--font-mono)', color: 'var(--color-primary)' }}>
            {t('Click any month to adjust crop', 'যেকোনো মাসে ক্লিক করে ফসল পরিবর্তন করুন')}
          </span>
        </div>

        <p style={{ fontSize: '0.84rem', color: 'var(--color-text-muted)', marginBottom: '1.15rem' }}>
          {t('Select the standing crop for each month (Jan–Dec). Changes update your farm profile immediately.', 'প্রতি মাসের জন্য (জান–ডিসেম্বর) দাঁড়ানো ফসল বেছে নিন। পরিবর্তনগুলি তাত্ক্ষণিকভাবে আপনার খামার প্রোফাইল আপডেট করে।')}
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(135px, 1fr))',
            gap: '0.6rem',
            paddingBottom: '0.5rem'
          }}
        >
          {MONTHS.map((m, idx) => {
            const currentItem = currentRotation[idx] || { month: m, crop: 'Fallow' };
            const cropName = currentItem.crop || 'Fallow';
            const styleKey = Object.keys(cropColors).find((k) => cropName.includes(k)) || 'Fallow';
            const c = cropColors[styleKey];

            return (
              <div
                key={m}
                style={{
                  background: c.bg,
                  border: `1.5px solid ${c.border}`,
                  borderRadius: 'var(--radius-md)',
                  padding: '0.6rem 0.45rem',
                  textAlign: 'center'
                }}
              >
                <div
                  style={{
                    fontSize: '0.76rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 700,
                    color: c.color,
                    marginBottom: '0.35rem'
                  }}
                >
                  {m}
                </div>
                <select
                  aria-label={`Select crop for ${m}`}
                  value={cropName}
                  onChange={(e) => handleRotationChange(idx, e.target.value)}
                  style={{
                    width: '100%',
                    fontSize: '0.73rem',
                    padding: '0.28rem 0.2rem',
                    borderRadius: '6px',
                    border: '1px solid var(--color-border)',
                    background: 'var(--color-surface)',
                    fontWeight: 600,
                    color: 'var(--color-text)',
                    cursor: 'pointer'
                  }}
                >
                  <option value="Aman Paddy">Aman Paddy</option>
                  <option value="Boro Paddy">Boro Paddy</option>
                  <option value="Potato">Potato</option>
                  <option value="Mustard">Mustard</option>
                  <option value="Moong">Moong</option>
                  <option value="Sesame">Sesame</option>
                  <option value="Jute">Jute</option>
                  <option value="Khesari">Khesari</option>
                  <option value="Lentil">Lentil</option>
                  <option value="Fallow">Fallow / Rest</option>
                </select>
                <div
                  style={{
                    fontSize: '0.66rem',
                    color: 'var(--color-text-muted)',
                    marginTop: '0.35rem',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}
                >
                  {currentItem.stage || 'Standing'}
                </div>
              </div>
            );
          })}
        </div>

        <div
          className="flex items-center gap-4"
          style={{
            marginTop: '0.9rem',
            paddingTop: '0.75rem',
            borderTop: '1px solid var(--color-border)',
            fontSize: '0.75rem',
            color: 'var(--color-text-muted)',
            flexWrap: 'wrap'
          }}
        >
          <span className="flex items-center gap-1">
            <span style={{ width: 10, height: 10, background: 'var(--color-primary)', borderRadius: 2 }} /> {t('Cereals', 'धान')}
          </span>
          <span className="flex items-center gap-1">
            <span style={{ width: 10, height: 10, background: '#B07525', borderRadius: 2 }} /> {t('Tubers', 'কंद')}
          </span>
          <span className="flex items-center gap-1">
            <span style={{ width: 10, height: 10, background: '#DCC9A3', borderRadius: 2 }} /> {t('Oilseeds', 'তিলহান')}
          </span>
          <span className="flex items-center gap-1">
            <span style={{ width: 10, height: 10, background: 'var(--color-primary)', borderRadius: 2 }} /> {t('Legumes', 'দল')}
          </span>
        </div>
      </div>

      {/* 2. Alternative Plans */}
      <div style={{ marginBottom: '2rem' }}>
        <div
          className="flex items-center justify-between"
          style={{ marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}
        >
          <div>
            <h2 style={{ fontSize: '1.4rem', color: 'var(--color-text)', marginBottom: '0.2rem' }}>
              {t('Recommended Crop Rotation Plans', 'প্রস্তাবিত ফসল আবর্তন পরিকল্পনা')}
            </h2>
            <p style={{ color: 'var(--color-text-muted)', fontSize: '0.86rem', margin: 0 }}>
              {t('Plans ranked for water-saving, nitrogen restoration, and pest-cycle interruption.', 'জল সাশ্রয়, নাইট্রোজেন পুনরুদ্ধার ও পোকা-চক্র ভঙ্গের জন্য পরিকল্পনাগুলো সারবরাহ করা হয়েছে।')}
            </p>
          </div>
          <span className="badge badge-success">{recommendations.length} {t('FEASIBLE CYCLES', 'সুবিধাজনক চক্র')}</span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {recommendations.map((plan, idx) => (
            <div
              key={plan.id || idx}
              className="card"
              style={{
                borderLeft: `4px solid ${idx === 0 ? 'var(--color-primary)' : 'rgba(120, 132, 123, 0.5)'}`
              }}
            >
              <div
                className="flex items-center justify-between"
                style={{ marginBottom: '0.85rem', flexWrap: 'wrap', gap: '0.65rem' }}
              >
                <div>
                  <span
                    style={{
                      fontSize: '0.72rem',
                      fontFamily: 'var(--font-mono)',
                      fontWeight: 700,
                      color: idx === 0 ? 'var(--color-primary)' : 'var(--color-text-muted)',
                      letterSpacing: '0.06em'
                    }}
                  >
                    OPTION 0{idx + 1} • {idx === 0 ? t('PRIMARY RECOMMENDED', 'প্রাথমিক সুপারিশকৃত') : t('ALTERNATIVE STRATEGY', 'বিকল্প কৌশল')}
                  </span>
                  <h3 style={{ fontSize: '1.25rem', color: 'var(--color-text)', marginTop: '0.15rem', marginBottom: 0 }}>
                    {plan.title}
                  </h3>
                </div>

                <div className="flex items-center gap-2" style={{ flexWrap: 'wrap' }}>
                  <div
                    style={{
                      padding: '0.38rem 0.8rem',
                      background: 'var(--color-success-bg)',
                      border: '1px solid rgba(46, 125, 50, 0.3)',
                      borderRadius: 'var(--radius-md)',
                      fontWeight: 700,
                      fontSize: '0.8rem',
                      color: 'var(--color-primary)'
                    }}
                  >
                    {plan.sequence}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleApplyPlanToCalendar(plan)}
                    className="btn btn-xs btn-primary"
                  >
                    <CheckCircle2 size={13} />
                    <span>
                      {appliedPlanId === plan.id ? t('Applied to Calendar!', 'ক্যালেন্ডারে প্রয়োগ করা!') : t('Apply to Calendar', 'ক্যালেন্ডারে প্রয়োগ করুন')}
                    </span>
                  </button>
                </div>
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
                  gap: '0.6rem',
                  marginBottom: '1.1rem'
                }}
              >
                {(plan.timing || []).map((tItem, tIdx) => (
                  <div
                    key={tIdx}
                    style={{
                      padding: '0.65rem 0.8rem',
                      background: 'var(--color-surface)',
                      borderRadius: 'var(--radius-md)',
                      border: '1px solid var(--color-border)'
                    }}
                  >
                    <div
                      style={{
                        fontSize: '0.72rem',
                        fontFamily: 'var(--font-mono)',
                        color: 'var(--color-primary)',
                        fontWeight: 700
                      }}
                    >
                      {tItem.window} ({tItem.duration})
                    </div>
                    <strong style={{ fontSize: '0.88rem', color: 'var(--color-text)', display: 'block', marginTop: '2px' }}>
                      {tItem.crop}
                    </strong>
                    <div style={{ fontSize: '0.7rem', color: 'var(--color-text-muted)' }}>
                      {tItem.type}
                    </div>
                  </div>
                ))}
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                  gap: '0.9rem',
                  marginBottom: '0.9rem'
                }}
              >
                <div
                  style={{
                    padding: '0.8rem',
                    background: 'var(--color-success-bg)',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid rgba(46, 125, 50, 0.3)',
                    fontSize: '0.82rem',
                    color: 'var(--color-text)'
                  }}
                >
                  <strong style={{ color: 'var(--color-primary)', display: 'block', marginBottom: '0.2rem' }}>
                    {t('Water Saving', 'জল সাশ্রয়')}
                  </strong>
                  {plan.waterBalance?.estimatedSavings || t('Reduced irrigation demand', 'সেচের চাহিদা হ্রাস')}
                </div>
                <div
                  style={{
                    padding: '0.8rem',
                    background: 'var(--color-success-bg)',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid rgba(46, 125, 50, 0.3)',
                    fontSize: '0.82rem',
                    color: 'var(--color-text)'
                  }}
                >
                  <strong style={{ color: 'var(--color-primary)', display: 'block', marginBottom: '0.2rem' }}>
                    {t('Soil Nitrogen', 'মাটির নাইট্রোজেন')}
                  </strong>
                  {plan.soilBenefit?.nitrogenContribution || t('Legume rotation adds nitrogen', 'ডাল শস্য নাইট্রোজেন যোগ করে')}
                </div>
                <div
                  style={{
                    padding: '0.8rem',
                    background: 'var(--color-surface)',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--color-border)',
                    fontSize: '0.82rem',
                    color: 'var(--color-text)'
                  }}
                >
                  <strong style={{ color: 'var(--color-primary)', display: 'block', marginBottom: '0.2rem' }}>
                    {t('Pest Cycle Break', 'পোকা-চক্র ভঙ্গ')}
                  </strong>
                  {plan.pestCycleBreak || t('Rotating crops disrupts pest buildup', 'ফসল আবর্তন পোকা বৃদ্ধি রোধ করে')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Simulation (Collapsed by default) */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div
          className="flex items-center justify-between"
          style={{ marginBottom: '1rem', cursor: 'pointer' }}
          onClick={() => setShowSimulation(!showSimulation)}
        >
          <div className="flex items-center gap-2">
            <Sliders size={20} style={{ color: 'var(--color-primary)' }} />
            <span style={{ fontWeight: 700, color: 'var(--color-text)' }}>
              {t('Test Weather Scenarios (What-If)', 'আবহাবা পরিস্থিতি পরীক্ষা (কি-হলে)')}
            </span>
          </div>
          <span
            style={{
              fontSize: '0.7rem',
              fontWeight: 700,
              color: showSimulation ? 'var(--color-primary)' : 'var(--color-text-muted)'
            }}
          >
            {showSimulation ? '▲' : '▼'}
          </span>
        </div>

        {showSimulation && (
          <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">{t('Sowing Delay (days)', 'বপন বিলম্ব (দিন)')}</label>
              <input
                type="number"
                className="form-input"
                value={delayDays}
                onChange={(e) => setDelayDays(Number(e.target.value) || 0)}
              />
            </div>
            <div className="form-group">
              <label className="form-label">{t('Temperature Offset (°C)', 'তাপমাত্রা পার্থক্য (°C)')}</label>
              <input
                type="number"
                step="0.5"
                className="form-input"
                value={tempOffset}
                onChange={(e) => setTempOffset(parseFloat(e.target.value) || 0)}
              />
            </div>
            <div className="form-group">
              <label className="form-label">{t('Rainfall Offset (%)', 'বৃষ্টিপাত পার্থক্য (%)')}</label>
              <input
                type="number"
                className="form-input"
                value={rainOffset}
                onChange={(e) => setRainOffset(Number(e.target.value) || 0)}
              />
            </div>
          </div>
          <div style={{ marginTop: '0.75rem' }}>
            <button
              type="button"
              onClick={() => runSimulation(delayDays, tempOffset, rainOffset)}
              className="btn btn-primary"
            >
              <Sun size={16} /> {t('Run Simulation', 'সিমুলেশন চলান')}
            </button>
          </div>

          {simulationResult && (
            <div
              style={{
                marginTop: '1rem',
                padding: '1rem',
                background: 'var(--color-success-bg)',
                borderRadius: 'var(--radius-md)',
                border: '1px solid rgba(46, 125, 50, 0.3)',
                fontSize: '0.85rem',
                color: 'var(--color-text)'
              }}
            >
              <strong style={{ color: 'var(--color-primary)', display: 'block', marginBottom: '0.4rem' }}>
                {t('Simulation Result', 'সিমুলেশন ফলাফল')}
              </strong>
              <div style={{ lineHeight: 1.6 }}>
                {simulationResult.summary || t('Review how delay, heat, or rainfall changes affect your crop plan.', 'বিলম্ব, তাপ বা বৃষ্টিপাতের পরিবর্তন আপনার ফসল পরিকল্পনাকে কীভাবে প্রভাবিত করে তা পর্যালোচনা করুন।')}
              </div>
            </div>
          )}
          </>
        )}
      </div>

      <DataSourceCard
        sourceName="Open Weather & Crop Calendar Sources"
        product="Seasonal Crop Rotation Planner"
        resolution="District Level"
        observationDate="Current Season"
        coverage={activeFarm.district}
        dataState="SAMPLE DATA"
        caveat="Crop plans are agronomic recommendations based on regional calendars. Always check local market demand and certified seed availability before planting."
      />
    </div>
  );
}
